import numpy as np
import pandas as pd
from sklearn.svm import SVR
from sklearn.metrics import mean_absolute_error


## Project-Part1
def predict_COVID_part1(svm_model, train_df, train_labels_df, past_cases_interval, past_weather_interval, test_feature):
    pass ## Replace this line with your implementation



## Project-Part2
def predict_COVID_part2(train_df, train_labels_df, test_feature):
    pass ## Replace this line with your implementation

